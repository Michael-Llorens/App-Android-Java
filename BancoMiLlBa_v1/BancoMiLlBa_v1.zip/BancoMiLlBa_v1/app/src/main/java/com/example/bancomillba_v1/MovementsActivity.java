package com.example.bancomillba_v1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.bancomillba_v1.pojo.Cliente;

public class MovementsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movements);

        Cliente c = new Cliente();


    }
}